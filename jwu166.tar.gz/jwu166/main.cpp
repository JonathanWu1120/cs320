#include <iostream>
#include <math.h>
#include <sstream>
#include <string>
#include <tuple>
#include <vector>
#include <fstream>

std::ofstream out;

void always_taken(std::vector<std::tuple<std::string,std::string,std::string>> in){
	int correct = 0;
	int total = 0;
	for(auto a : in){
		++total;
		if(std::get<1>(a) == "T"){
			++correct;
		}
	}
	out << correct << "," << total << ";\n";
}

void always_not_taken(std::vector<std::tuple<std::string,std::string,std::string>> in){
	int correct = 0;
	int total = 0;
	for(auto a : in){
		++total;
		if(std::get<1>(a) == "NT"){
			++correct;
		}
	}
	out << correct << "," << total << ";\n";
}

void bimodal_predictor1(std::vector<std::tuple<std::string,std::string,std::string>> in){
	int c1 = 0;
	int c2 = 0;
	int c3 = 0;
	int c4 = 0;
	int c5 = 0;
	int c6 = 0;
	int c7 = 0;
	int total = 0;
	std::vector<int> a1(16,1);
	std::vector<int> a2(32,1);
	std::vector<int> a3(128,1);
	std::vector<int> a4(256,1);
	std::vector<int> a5(512,1);
	std::vector<int> a6(1024,1);
	std::vector<int> a7(2048,1);
	for(auto a : in){
		unsigned int x;
		std::stringstream ss;
		std::string pc = std::get<0>(a);
		int i = pc.size();
		std::string ind = "";
		ind += pc.at(i-3);
		ind += pc.at(i-2);
		ind += pc.at(i-1);
		ss << ind;
		ss >> std::hex >> x;
		if(a1[x%16]){
			if(std::get<1>(a) == "NT"){
				a1[x%16] = 0;
			}else{
				c1++;
			}
		}else{
			if(std::get<1>(a) == "T"){
				a1[x%16] = 1;
			}else{
				c1++;
			}
		}
		if(a2[x%32]){
			if(std::get<1>(a) == "NT"){
				a2[x%32] = 0;
			}else{
				c2++;
			}
		}else{
			if(std::get<1>(a) == "T"){
				a2[x%32] = 1;
			}else{
				c2++;
			}
		}
		if(a3[x%128]){
			if(std::get<1>(a) == "NT"){
				a3[x%128] = 0;
			}else{
				c3++;
			}
		}else{
			if(std::get<1>(a) == "T"){
				a3[x%128] = 1;
			}else{
				c3++;
			}
		}
		if(a4[x%256]){
			if(std::get<1>(a) == "NT"){
				a4[x%256] = 0;
			}else{
				c4++;
			}
		}else{
			if(std::get<1>(a) == "T"){
				a4[x%256] = 1;
			}else{
				c4++;
			}
		}
		if(a5[x%512]){
			if(std::get<1>(a) == "NT"){
				a5[x%512] = 0;
			}else{
				c5++;
			}
		}else{
			if(std::get<1>(a) == "T"){
				a5[x%512] = 1;
			}else{
				c5++;
			}
		}
		if(a6[x%1024]){
			if(std::get<1>(a) == "NT"){
				a6[x%1024] = 0;
			}else{
				c6++;
			}
		}else{
			if(std::get<1>(a) == "T"){
				a6[x%1024] = 1;
			}else{
				c6++;
			}
		}
		if(a7[x%2048]){
			if(std::get<1>(a) == "NT"){
				a7[x%2048] = 0;
			}else{
				c7++;
			}
		}else{
			if(std::get<1>(a) == "T"){
				a7[x%2048] = 1;
			}else{
				c7++;
			}
		}
		++total;
	}
	out << c1 << "," << total << "; "; 
	out << c2 << "," << total << "; "; 
	out << c3 << "," << total << "; "; 
	out << c4 << "," << total << "; "; 
	out << c5 << "," << total << "; "; 
	out << c6 << "," << total << "; "; 
	out << c7 << "," << total << ";\n"; 
}

int get_pc_shifted(std::tuple<std::string,std::string,std::string> a){
	unsigned int x;
	std::stringstream ss;
	std::string pc = std::get<0>(a);
	int i = pc.size();
	std::string ind = "";
	ind += pc.at(i-3);
	ind += pc.at(i-2);
	ind += pc.at(i-1);
	ss << ind;
	ss >> std::hex >> x;
	return x;
}

void bimodal_predictor2(std::vector<std::tuple<std::string,std::string,std::string>> in){
	int total = 0;
	std::vector<int> a1(16,3);
	std::vector<int> a2(32,3);
	std::vector<int> a3(128,3);
	std::vector<int> a4(256,3);
	std::vector<int> a5(512,3);
	std::vector<int> a6(1024,3);
	std::vector<int> a7(2048,3);
	int cc [7] = {0};
	std::vector<std::vector<int>> mmm{a1,a2,a3,a4,a5,a6,a7};
	for(auto a : in){
		unsigned int x = get_pc_shifted(a);
		++total;
		std::string s = std::get<1>(a);
		 // This was written since i did not want to repeat the same code 7 times
		for(int j = 0; j < 7;j++){
		        int k = j > 1 ? pow(2,j+5) : pow(2,j+4);
			int p = mmm[j][x%k];
			if(p == 3){
				if(s == "NT"){
					mmm[j][x%k] = 2;
				}else{
					cc[j] += 1;
				}
			}else if(p == 2){
				if(s == "NT"){
					mmm[j][x%k] = 1;
				}else{
					mmm[j][x%k] = 3;
					cc[j] += 1;
				}
			}else if(p ==1){
				if(s == "T"){
					mmm[j][x%k] = 2;
				}else{
					mmm[j][x%k] = 0;
					cc[j] += 1;
				}
			}else{
				if(s == "T"){
					mmm[j][x%k] = 1;
				}else{
					cc[j] += 1;
				}
			}
		}
	}
	out << cc[0] << "," << total << "; "; 
	out << cc[1] << "," << total << "; "; 
	out << cc[2] << "," << total << "; "; 
	out << cc[3] << "," << total << "; "; 
	out << cc[4] << "," << total << "; "; 
	out << cc[5] << "," << total << "; "; 
	out << cc[6] << "," << total << ";\n" ; 
}

void gshare_predictor(std::vector<std::tuple<std::string,std::string,std::string>> in){
	int c [9] = {0};
	int total = in.size();
	std::vector<std::vector<int>> table(9,std::vector<int>(2048,3));
	for(int i = 3; i < 12; i++){
		unsigned int ghist = 0;
		int mod = pow(2,i);
		for(auto a : in){
			std::string T = std::get<1>(a);
			unsigned int x = get_pc_shifted(a);
			x = x % table[i-3].size();
			unsigned int index = x ^ ghist;
			int pred = table[i-3][index];
			ghist *= 2;
			if(T == "T"){
				ghist++;
				if(pred == 3 || pred == 2){
					c[i-3] += 1;
					table[i-3][index] = 3;
				}else{
					table[i-3][index] += 1;
				}
			}else{
				if(pred == 0 || pred == 1){
					c[i-3] += 1;
					table[i-3][index] = 0;
				}else{
					table[i-3][index] -= 1;
				}
			}
			ghist = ghist % mod;	
		}
	}
	out << c[0] << "," << total << "; "; 
	out << c[1] << "," << total << "; "; 
	out << c[2] << "," << total << "; "; 
	out << c[3] << "," << total << "; "; 
	out << c[4] << "," << total << "; "; 
	out << c[5] << "," << total << "; "; 
	out << c[6] << "," << total << "; "; 
	out << c[7] << "," << total << "; "; 
	out << c[8] << "," << total << ";\n"; 
}

void tournament_predictor(std::vector<std::tuple<std::string,std::string,std::string>> in){
	std::vector<int> g(2048,3);
	std::vector<int> b(2048,3);
	int c = 0;
	std::vector<int> t(2048,0);
	unsigned int ghist = 0;
	for(auto a:in){
		std::string T = std::get<1>(a);
		unsigned int x = get_pc_shifted(a);
		bool gshare = false;
		bool bimodal = false;
		x = x % 2048;
		int bpred = b[x];
		unsigned int index = x ^ ghist;
		int pred = g[index];
		ghist *= 2;
		if(T == "T"){
			ghist++;
		}
		if(bpred == 3){
			if(T == "NT"){
				b[x] = 2;
				bimodal = false;
			}else{
				bimodal = true;
			}
		}else if(bpred == 2){
			if(T == "NT"){
				b[x] = 1;
				bimodal = false;
			}else{
				b[x] = 3;
				bimodal = true;
			}
		}else if(bpred ==1){
			if(T == "T"){
				b[x] = 2;
				bimodal = false;
			}else{
				b[x] = 0;
				bimodal = true;
			}
		}else{
			if(T == "T"){
				b[x] = 1;
				bimodal = false;
			}else{
				bimodal = true;
			}
		}
		if(T == "T"){
			if(pred == 3 || pred == 2){
				gshare = true;
				g[index] = 3;
			}else{
				g[index] += 1;
				gshare = false;
			}
		}else{
			if(pred == 0 || pred == 1){
				gshare = true;
				g[index] = 0;
			}else{
				g[index] -= 1;
				gshare = false;
			}
		}
		ghist = ghist % 2048;	
		if(t[x] <= 1 && gshare == true){
			c++;
		}else if(t[x] >=2 && bimodal == true){
			c++;
		}

		if(bimodal == true && gshare == false){
			if(t[x] < 3){
				++t[x];
			}
		}else if(gshare == true && bimodal == false){
			if(t[x] > 0){
				--t[x];
			}
		}
	}
	out << c << "," << in.size() << ";\n";
}

void branch_target_buffer(std::vector<std::tuple<std::string,std::string,std::string>> in){
	int total = 0;
	std::vector<int> b(512,1);
	int c = 0;
	std::vector<std::tuple<std::string,std::string>> btb;
	btb.resize(128);
	for(auto a : in){
		std::string T = std::get<1>(a);
		unsigned int x;
		std::stringstream ss;
		std::string pc = std::get<0>(a);
		int i = pc.size();
		std::string ind = "";
		ind += pc.at(i-3);
		ind += pc.at(i-2);
		ind += pc.at(i-1);
		ss << ind;
		ss >> std::hex >> x;
		x = x % 512;
		int bpred = b[x];
		
		if(bpred == 1){
			++total;
			int y = x % 128;
			std::string tpc = std::get<0>(btb[y]);
			std::string target = std::get<2>(a);
			if(tpc != pc){
				btb[y] = std::make_tuple(pc,target);
			}else{
				if(std::get<1>(btb[y]) == target){
					c++;
				}else{
					btb[y] = std::make_tuple(pc,target);
				}
			}
			if(T == "NT"){
				b[x] = 0;
			}
		}else{
			if(T == "T"){
				b[x] = 1;
			}
		}
	}
	out << total << "," << c << ";\n" ;
}

int main(int argc, char** argv){
	if(argc != 3){
		std::cerr << "Incorrect input format, please format as ./predictors input.txt output.txt" ;
		return 0;
	}
	std::string line;
	std::ifstream infile(argv[1]);
	std::vector<std::tuple<std::string,std::string,std::string>> input;
	while(std::getline(infile,line)){
		std::istringstream iss(line);
		std::string a, b, c;
		if(!(iss >> a >> b >> c)){
			break;
		}
		auto x = std::make_tuple(a,b,c);
		input.push_back(x);
	}
	out.open(argv[2]);
	always_taken(input);
	always_not_taken(input);
	std::cout <<"Always finished" << std::endl;
	bimodal_predictor1(input);
	bimodal_predictor2(input);
	std::cout << "Bimodal finished" << std::endl;
	gshare_predictor(input);
	std::cout << "Gshare finished" << std::endl;
	tournament_predictor(input);
	std::cout << "Tourney finished" << std::endl;
	branch_target_buffer(input);
	out.close();
	std::cout << "Finished" << std::endl;
	return 0;
}

